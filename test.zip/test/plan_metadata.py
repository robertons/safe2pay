# -*- coding: utf-8 -*-
import json
import sys

sys.path.append('/Volumes/Sandisk/Projetos/pagarme')

import pagarmepy

import uuid

from datetime import datetime

def main(arg):
    pagarmepy.PagarMe('acc_L3vxGpMF71h56nyK','pk_test_Y479512hrHMQ956j', 'sk_test_nDjEyXohVeSVA0Nl', sandbox=True, debug=True)


    plano = pagarmepy.Plan(id="plan_VR92ne8UEUGWNMAa").ChangeMetadata(
        teste = 'valor 1',
        teste2 = 'valor 2',
        numero = 3
    )

    print(plano.toJSON())

if __name__ == "__main__":
    main(sys.argv)
