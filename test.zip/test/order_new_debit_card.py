# -*- coding: utf-8 -*-
import json
import sys

sys.path.append('/Volumes/Sandisk/Projetos/pagarme')

import pagarmepy

import uuid


def main(arg):
    pagarmepy.PagarMe('acc_L3vxGpMF71h56nyK','pk_test_Y479512hrHMQ956j', 'sk_test_nDjEyXohVeSVA0Nl', sandbox=True, debug=True)


    pedido = pagarmepy.Order()
    pedido.customer_id = "cus_bjgeDobsLsEO48nw"
    pedido.code =  "62LVFN7I4R"
    pedido.amount = 2900
    pedido.currency =  "BRL"
    pedido.items.add(pagarmepy.Item(**{
            "id": "oi_d478RMAS3bC74PrL",
            "description": "Chaveiro do Tesseract",
            "amount": 2900,
            "quantity": 1,
            "status": "active",
            "code":"abc"
        }))

    pedido.shipping = pagarmepy.Shipping(**{
        "amount": 100,
        "description": "Stark",
        "recipient_name": "Tony Stark",
        "recipient_phone": "24586787867",
        "address": {
            "line_1": "10880, Malibu Point, Malibu Central",
            "zip_code": "90265",
            "city": "Malibu",
            "state": "CA",
            "country": "US"
        }})

    pedido.payments.add(pagarmepy.Payment(**{
            "payment_method": "debit_card",
            "debit_card": {
                "statement_descriptor": "AVENGERS",
                "card": {
                    "number": "4000000000000010",
                    "holder_name": "Tony Stark",
                    "exp_month": 12,
                    "exp_year": 30,
                    "cvv": "235"
                },
            "authentication": {
                "type": "threed_secure",
                "threed_secure": {
                    "mpi": "acquirer",
                    "success_url": "http://www.pagar.me"
                }
            }
        }}))

    pedido.Create()

    print(pedido.toJSON())

if __name__ == "__main__":
    main(sys.argv)
