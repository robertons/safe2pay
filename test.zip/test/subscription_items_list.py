# -*- coding: utf-8 -*-
import json
import sys

sys.path.append('/Volumes/Sandisk/Projetos/pagarme')

import pagarmepy

import uuid

from datetime import datetime

def main(arg):
    pagarmepy.PagarMe('acc_L3vxGpMF71h56nyK','pk_test_Y479512hrHMQ956j', 'sk_test_nDjEyXohVeSVA0Nl', sandbox=True, debug=True)


    items_asssinaturas = pagarmepy.Subscription(id="sub_1VRDB5AfWfjBnZpx").ListItems()
    print(items_asssinaturas.toJSON())

if __name__ == "__main__":
    main(sys.argv)
