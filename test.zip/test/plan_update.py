# -*- coding: utf-8 -*-
import json
import sys

sys.path.append('/Volumes/Sandisk/Projetos/pagarme')

import pagarmepy

import uuid


def main(arg):
    pagarmepy.PagarMe('acc_L3vxGpMF71h56nyK','pk_test_Y479512hrHMQ956j', 'sk_test_nDjEyXohVeSVA0Nl', sandbox=True, debug=True)

    plano = pagarmepy.Plan(id="plan_ODjw15Af9WUgzwkg").Get()
    plano.statement_descriptor = "AST Test"
    plano.Update()
    print(plano.toJSON())

if __name__ == "__main__":
    main(sys.argv)
