# -*- coding: utf-8 -*-
import json
import sys

sys.path.append('/Volumes/Sandisk/Projetos/pagarme')

import pagarmepy

import uuid


def main(arg):
    pagarmepy.PagarMe('acc_L3vxGpMF71h56nyK','pk_test_Y479512hrHMQ956j', 'sk_test_nDjEyXohVeSVA0Nl', sandbox=True, debug=True)


    recebedor = pagarmepy.Recipient(id="rp_JPx17b8H9HgwY5zo").Get()

    print(recebedor.toJSON())
    print(recebedor.default_bank_account.id)

if __name__ == "__main__":
    main(sys.argv)
