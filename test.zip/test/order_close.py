# -*- coding: utf-8 -*-
import json
import sys

sys.path.append('/Volumes/Sandisk/Projetos/pagarme')

import pagarmepy

import uuid


def main(arg):
    pagarmepy.PagarMe('acc_L3vxGpMF71h56nyK','pk_test_Y479512hrHMQ956j', 'sk_test_nDjEyXohVeSVA0Nl', sandbox=True, debug=True)


    pedido = pagarmepy.Order(id="or_jP82N8VUpXhyYr4b").Close()


    print(pedido.toJSON())

if __name__ == "__main__":
    main(sys.argv)
