# -*- coding: utf-8 -*-
import json
import sys

sys.path.append('/Volumes/Sandisk/Projetos/pagarme')

import pagarmepy

import uuid


def main(arg):
    pagarmepy.PagarMe('acc_L3vxGpMF71h56nyK','pk_test_Y479512hrHMQ956j', 'sk_test_nDjEyXohVeSVA0Nl', sandbox=True, debug=True)


    assinatura = pagarmepy.Subscription()
    assinatura.code = '1234'
    assinatura.customer_id = "cus_bjgeDobsLsEO48nw"
    assinatura.interval = 'month'
    assinatura.interval_count = 1
    assinatura.currency = 'BRL'
    assinatura.payment_method = "credit_card"
    assinatura.billing_type = 'prepaid'
    assinatura.installments = 1
    assinatura.statement_descriptor = "AST Gofans"
    assinatura.items.add(pagarmepy.Item(**{
            "id": "oi_d478RMAS3bC74PrL",
            "description": "Chaveiro do Tesseract",
            "amount": 2900,
            "quantity": 1,
            "status": "active",
            "code":"abc",
            "pricing_scheme":{
                "scheme_type": "Unit",
                "price": 2900
            }
        }))
    assinatura.card = pagarmepy.Card(**{
        "number": "4000000000000010",
        "holder_name": "Tony Stark",
        "exp_month": 1,
        "exp_year": 30,
        "cvv": "3531",
        "billing_address": {
            "line_1": "10880, Malibu Point, Malibu Central",
            "zip_code": "90265",
            "city": "Malibu",
            "state": "CA",
            "country": "US"
        }
    })

    assinatura.Create()

    print(assinatura.toJSON())

if __name__ == "__main__":
    main(sys.argv)
